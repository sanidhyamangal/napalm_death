I'm James, designer of the font 'James Fajardo.' I'm always very happy to hear about people using my font.

For commercial use, please consider the new, complete version of this font: James Paul. This font is highly influenced by the design of 'Fajardo.' Consider it a more complete and useable cousin of 'James Fajardo.'

The redesign includes more legible letterforms, complete character sets and extras while keeping the lively, spirited quality of the original. The new version has over 480 glyphs, Western Europe diacritics, Central European, Turkish and Baltic characters, mathematical symbols, ligatures, alternate characters, dingbats and symbols. You can check out the character map and test the font here:
http://www.myfonts.com/fonts/fajardo/james-paul/

Thank you!
- James Fajardo